package com.shivamkibhu.googlesearchnew;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.paging.FirestorePagingAdapter;
import com.firebase.ui.firestore.paging.FirestorePagingOptions;

import java.util.List;

public class ImageAdapter extends FirestorePagingAdapter<ImageModel, ImageAdapter.ImageViewholder> {
    private Context contextVar;
    private String urls="";
    private List<ImageModel> imageModels;

    public ImageAdapter(@NonNull Context context, FirestorePagingOptions<ImageModel> options, String urls) {
        super(options);
        contextVar = context;
        this.urls = urls;
    }

    @Override
    protected void onBindViewHolder(@NonNull ImageViewholder holder, int position, @NonNull ImageModel imagemodel) {
        RequestOptions requestOptions = new RequestOptions().placeholder(R.drawable.logo);
        requestOptions.transforms(new RoundedCorners(40));
        requestOptions.error(R.drawable.error);

        Glide.with(contextVar).load(urls).apply(requestOptions).into(holder.imageItem);

    }

    @NonNull
    @Override
    public ImageViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.imageitem_design, parent, false);
        return new ImageViewholder(view);
    }

    public class ImageViewholder extends RecyclerView.ViewHolder {
        ImageView imageItem;

        public ImageViewholder(@NonNull View itemView) {
            super(itemView);
            imageItem = itemView.findViewById(R.id.imageItems);
        }
    }
}
