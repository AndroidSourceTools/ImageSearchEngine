package com.shivamkibhu.googlesearchnew;

public class Trie {
    int value;
    Trie left,right;
    public Trie(int value){
        this.value=value;
    }
}
