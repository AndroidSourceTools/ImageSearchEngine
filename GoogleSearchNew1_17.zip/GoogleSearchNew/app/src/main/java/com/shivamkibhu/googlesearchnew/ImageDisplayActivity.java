package com.shivamkibhu.googlesearchnew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.paging.PagedList;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.paging.FirestorePagingOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ImageDisplayActivity extends AppCompatActivity {
    private FirebaseFirestore db_Reference;
    private CollectionReference collectionReference;
    private ImageAdapter imageAdapter;
    private RecyclerView imagelist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_display);

        db_Reference = FirebaseFirestore.getInstance();
        collectionReference = db_Reference.collection("arrayUrls");
        setUpRecylerview();
    }


    public void setUpRecylerview() {
        Query query = collectionReference;
        PagedList.Config config = new PagedList.Config.Builder().setInitialLoadSizeHint(10).setPageSize(5).build();
        final FirestorePagingOptions<ImageModel> firestoreRecyclerOptions = new FirestorePagingOptions.Builder<ImageModel>()
                .setLifecycleOwner(this).setQuery(query, config, ImageModel.class).build();
//        imageAdapter = new ImageAdapter(ImageDisplayActivity.this, firestoreRecyclerOptions);
//
//        imagelist = findViewById(R.id.imageDisplay_recycler);
//        StaggeredGridLayoutManager staggeredGrid = new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL);
//        imagelist.setLayoutManager(staggeredGrid);
//        imagelist.setAdapter(imageAdapter);


        final DocumentReference docRef = collectionReference.document("dhoni");
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                List<String> urls = (List<String>) documentSnapshot.get("urls");
                for (String url : urls) {
                    imageAdapter = new ImageAdapter(ImageDisplayActivity.this, firestoreRecyclerOptions, url);
                    imagelist.setAdapter(imageAdapter);

                }
            }
        });
//        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
//                if(task.isSuccessful()){
//                    DocumentSnapshot document = task.getResult();
//                    if(document.exists()){
//                        urls = (List<String>) document.get("urls");
//                        for(String url : urls)
//                            imageAdapter = new ImageAdapter(ImageDisplayActivity.this, firestoreRecyclerOptions, url);
//                    }
//                }
//            }
//        });

//        collectionReference.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                if(task.isSuccessful()){
//                    for(QueryDocumentSnapshot document : task.getResult()){
//                        ImageModel imageModel = document.toObject(ImageModel.class);
//                        urls = imageModel.getUrls();
//
////                        if(document.equals("dhoni")){
////                            urls = document.get("urls");
////                        }
//                    }
//                }
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(ImageDisplayActivity.this, "" + e.toString(), Toast.LENGTH_SHORT).show();
//            }
//        });


        imagelist = findViewById(R.id.imageDisplay_recycler);
        StaggeredGridLayoutManager staggeredGrid = new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL);
        imagelist.setLayoutManager(staggeredGrid);
    }


}
