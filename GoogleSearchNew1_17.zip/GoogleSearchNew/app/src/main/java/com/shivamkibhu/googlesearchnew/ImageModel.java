package com.shivamkibhu.googlesearchnew;

import java.util.List;

public class ImageModel {
//    String imageurls;
//    public ImageModel(){
//
//    }
//    public ImageModel(String imageurls) {
//        this.imageurls = imageurls;
//    }
//
//    public String getImageurls() {
//        return imageurls;
//    }
//
//    public void setImageurls(String imageurls) {
//        this.imageurls = imageurls;
//    }
    String urls;
    public ImageModel(){}

    public ImageModel(String urls){
        this.urls = urls;
    }

    public String getUrls() {
        return urls;
    }

    public void setUrls(String urls) {
        this.urls = urls;
    }
}
