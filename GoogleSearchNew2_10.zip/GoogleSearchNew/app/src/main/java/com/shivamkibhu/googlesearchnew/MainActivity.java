package com.shivamkibhu.googlesearchnew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView searchImageText;
    private ImageView searchButton;
    private static final String SHAREDPREF = "google";
    private static final String SUGGESTIONS = "suggestions";
    private static final String MINCOUNT = "minCount";
    public static SharedPreferences sharedPreferences;
    private static final String TRIE = "trie";

    List<String> keywords = new ArrayList<>(Arrays.asList("one", "sibanii", "little", "indian",
            "uniquejii", "litila", "indiyana", "onion", "sibanarayan", "silicon", "universe", "until", "unlimited", "sandeep"));

    private FirebaseFirestore db_Reference;
    private CollectionReference collectionReference;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        createTrie();

        searchImageText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (searchImageText.getText().toString().trim().length() == 0)
                    showOptions();
                else searchInTrie(searchImageText.getText().toString());

                searchImageText.showDropDown();
                return false;
            }
        });

        searchImageText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(searchImageText.getText().toString().trim().length() == 0) showOptions();
                else searchInTrie(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchImageText.getText().toString().isEmpty()) Movetonext();
            }
        });
        searchImageText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (!searchImageText.getText().toString().isEmpty() && actionId == EditorInfo.IME_ACTION_SEARCH)
                    Movetonext();
                return false;
            }
        });
    }

    private void searchInTrie(CharSequence s) {
        List<String> words = new ArrayList<>();
        Gson gson = new Gson();
        String json = sharedPreferences.getString(TRIE, null);
        Type type = new TypeToken<Trie>() {
        }.getType();
        Trie sugg = gson.fromJson(json, type);
        if (sugg != null) {
            boolean rightKeyword = true;
            for(Character c : s.toString().toCharArray()){
                if(sugg.children.containsKey(c+""))
                    sugg = sugg.children.get(c+"");
                else rightKeyword = false;
            }
            if(rightKeyword) searchFurtherKey(sugg, words);
        }

        String[] sug = new String[words.size()];
        for(int i = 0; i < words.size(); i++)
            sug[i] = words.get(i);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sug);
        searchImageText.setAdapter(adapter);

    }

    private void searchFurtherKey(Trie sugg, List<String> words) {
        if(words.size() >= 4) return;
        if(sugg.children.containsKey("*")) {
            words.add(sugg.completeWord);
            return;
        }
        for(String s : sugg.children.keySet())
            searchFurtherKey(sugg.children.get(s), words);

    }


    private void createTrie() {
        Trie root = new Trie("");
        for(String keyword : keywords)
            buildTrie(keyword, root);

        Gson gson1 = new Gson();
        String arrayToString = gson1.toJson(root);
        SharedPreferences.Editor editor2 = sharedPreferences.edit();
        editor2.putString(TRIE, arrayToString);
        editor2.apply();
    }

    private void buildTrie(String keyword, Trie root){
        Trie node = root;
        for(char c : keyword.toCharArray()){
            if(!node.children.containsKey(c+""))
                node.children.put(c+"", new Trie(""));

            node = node.children.get(c+"");
        }
        node.children.put("*", new Trie(""));
        node.completeWord = keyword;
    }

    private void showOptions() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(SUGGESTIONS, null);
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        List<String> sugg = gson.fromJson(json, type);

        if (sugg == null)
            sugg = new ArrayList<>();
        String[] suggestions = new String[sugg.size()];
        for (int i = 0; i < sugg.size(); i++)
            suggestions[i] = sugg.get(i);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, suggestions);
        searchImageText.setAdapter(adapter);
    }

    private void Movetonext() {
        //TODO: need to verify query is present in database or not
        String query = searchImageText.getText().toString();

        if(keywords.contains(query)) {
            Intent moveToNext = new Intent(this, ImageDisplayActivity.class);
            moveToNext.putExtra("searchQuery", query);
            startActivity(moveToNext);

            SharedPreferences.Editor editor = sharedPreferences.edit();
            //Put the value to sharedPreference
            int preCount = sharedPreferences.getInt(query, 0);
            editor.putInt(query, preCount + 1);
            editor.apply();

            //Read suggestion array
            Gson gson = new Gson();
            String json = sharedPreferences.getString(SUGGESTIONS, null);
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            List<String> sugg = gson.fromJson(json, type);

            if (sugg == null) sugg = new ArrayList<>();

            if (!sugg.contains(query)) {
                if (sugg.size() >= 5) {
                    if (sharedPreferences.getInt(MINCOUNT, Integer.MIN_VALUE) < preCount + 1) {
                        // Update suggestions array
                        for (String s : sugg) {
                            if (sharedPreferences.getInt(s, -1) == sharedPreferences.getInt(MINCOUNT, -2)) {
                                sugg.remove(sugg.indexOf(s));
                                sugg.add(query);
                                break;
                            }
                        }

                    }
                } else sugg.add(query);

                String arrayToString = gson.toJson(sugg);
                editor.putString(SUGGESTIONS, arrayToString);
            }
            int min = Integer.MAX_VALUE;
            for (String option : sugg)
                min = Math.min(min, sharedPreferences.getInt(option, Integer.MAX_VALUE));

            editor.putInt(MINCOUNT, min);
            editor.apply();
        }else
            Toast.makeText(this, "Sorry!! No data found.Please search right keywords??", Toast.LENGTH_SHORT).show();
    }

    private void init() {
        searchImageText = findViewById(R.id.search_edtText);
        searchButton = findViewById(R.id.searchIcon);
        sharedPreferences = getSharedPreferences(SHAREDPREF, MODE_PRIVATE);

        db_Reference = FirebaseFirestore.getInstance();
        collectionReference = db_Reference.collection("keywords");

        collectionReference.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot snapshot = task.getResult();
                    int size = snapshot.size();
                    Toast.makeText(MainActivity.this, "" + size, Toast.LENGTH_SHORT).show();
                    int i = 1;
                    List<String> list = new ArrayList<>();
                    for (QueryDocumentSnapshot s : snapshot) {
                        if (i++ <= 2) continue;
                        Map<String, Object> map = s.getData();
                        list.add((String) map.get("name"));

//                        Toast.makeText(MainActivity.this, s.getId() + " ", Toast.LENGTH_SHORT).show();
//                        break;
                    }
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }
}