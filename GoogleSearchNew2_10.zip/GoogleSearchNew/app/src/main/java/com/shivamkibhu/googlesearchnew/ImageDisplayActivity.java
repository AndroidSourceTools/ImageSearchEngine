package com.shivamkibhu.googlesearchnew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import static com.shivamkibhu.googlesearchnew.MainActivity.sharedPreferences;

public class ImageDisplayActivity extends AppCompatActivity {
    private FirebaseFirestore db_Reference;
    private CollectionReference collectionReference;
    private ImageAdapter imageAdapter;
    private RecyclerView imagelist;
    TextView next, pre;
    int min = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_display);

        db_Reference = FirebaseFirestore.getInstance();
        collectionReference = db_Reference.collection("arrayUrls");

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("Min", min);
        editor.apply();
        setUpRecylerview();
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retriveImages();
            }
        });

        if(sharedPreferences.getInt("Min", 0) < 10) pre.setVisibility(View.INVISIBLE);

        pre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadPre();
            }
        });
    }

    public void setUpRecylerview() {
        next = findViewById(R.id.next);
        pre = findViewById(R.id.pre);
        imagelist = findViewById(R.id.imageDisplay_recycler);

        retriveImages();

    }

    private void retriveImages() {
        final DocumentReference docRef = collectionReference.document("dhoni");
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                List<String> urls = (List<String>) documentSnapshot.get("urls");
                List<String> urllist = new ArrayList<>();
                int val = sharedPreferences.getInt("Min", 0);
                if(val > 1) pre.setVisibility(View.VISIBLE);
                for (int i = val; i < val + 10; i++) {
                    if (i < urls.size()) {
                        urllist.add(urls.get(i));
                        min = i;
                    } else {
                        next.setVisibility(View.GONE);
                        break;
                    }
                }
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("Min", min + 1);
                editor.apply();
                imageAdapter = new ImageAdapter(ImageDisplayActivity.this, urllist);
                StaggeredGridLayoutManager staggeredGrid = new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL);
                imagelist.setLayoutManager(staggeredGrid);
                imagelist.setAdapter(imageAdapter);

            }
        });
    }

    private void loadPre() {
        final DocumentReference docRef = collectionReference.document("dhoni");
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                List<String> urls = (List<String>) documentSnapshot.get("urls");
                List<String> urllist = new ArrayList<>();
                int val = sharedPreferences.getInt("Min", 0);
                int rem = val % 10;
                val -= rem;
                if(val < 11) pre.setVisibility(View.GONE);
                else pre.setVisibility(View.VISIBLE);
                if(val > 0) {
                    next.setVisibility(View.VISIBLE);
                    min = val;
                    for (int i = val - 9; i <= val; i++) {
                        if (i < urls.size()) {
                            urllist.add(urls.get(i));
                        } else {
                            next.setVisibility(View.GONE);
                            break;
                        }
                    }

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putInt("Min", min - 1);
                    editor.apply();
                    imageAdapter = new ImageAdapter(ImageDisplayActivity.this, urllist);
                    StaggeredGridLayoutManager staggeredGrid = new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL);
                    imagelist.setLayoutManager(staggeredGrid);
                    imagelist.setAdapter(imageAdapter);
                }

            }
        });
    }
}
