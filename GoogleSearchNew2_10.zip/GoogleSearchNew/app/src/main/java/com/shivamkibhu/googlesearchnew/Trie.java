package com.shivamkibhu.googlesearchnew;

import java.util.HashMap;
import java.util.List;

public class Trie {
    String alphabet;
    HashMap<String, Trie> children;
    String completeWord;

    public Trie(String alphabet){
        this.alphabet = alphabet;
        children = new HashMap<>();
    }
}
