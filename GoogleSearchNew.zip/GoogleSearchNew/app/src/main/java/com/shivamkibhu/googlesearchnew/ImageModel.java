package com.shivamkibhu.googlesearchnew;

public class ImageModel {
    String imageurls;
    public ImageModel(){

    }
    public ImageModel(String imageurls) {
        this.imageurls = imageurls;
    }

    public String getImageurls() {
        return imageurls;
    }

    public void setImageurls(String imageurls) {
        this.imageurls = imageurls;
    }
}
