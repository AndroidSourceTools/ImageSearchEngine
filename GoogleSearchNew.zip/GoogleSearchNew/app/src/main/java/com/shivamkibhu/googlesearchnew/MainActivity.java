package com.shivamkibhu.googlesearchnew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView searchImageText;
    private ImageView searchButton;
    private static final String SHAREDPREF = "google";
    private static final String SUGGESTIONS = "suggestions";
    private static final String MINCOUNT = "minCount";
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        searchImageText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                showOptions();
                searchImageText.showDropDown();
                return false;
            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchImageText.getText().toString().isEmpty()) Movetonext();
            }
        });
        searchImageText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (!searchImageText.getText().toString().isEmpty() && actionId == EditorInfo.IME_ACTION_SEARCH)
                    Movetonext();
                return false;
            }
        });
    }

    private void showOptions() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString(SUGGESTIONS, null);
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        List<String> sugg = gson.fromJson(json, type);

        if(sugg == null)
            sugg = new ArrayList<>();
        String[] suggestions = new String[sugg.size()];
        for(int i = 0; i < sugg.size(); i++)
            suggestions[i] = sugg.get(i);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, suggestions);
        searchImageText.setAdapter(adapter);
    }

    private void Movetonext() {
        String query = searchImageText.getText().toString();

        Intent moveToNext = new Intent(this, ImageDisplayActivity.class);
        moveToNext.putExtra("searchQuery", query);
        startActivity(moveToNext);

//        sharedPreferences = getSharedPreferences(SHAREDPREF, MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        //Put the value to sharedPreference
        int preCount = sharedPreferences.getInt(query, 0);
        editor.putInt(query, preCount + 1);
        editor.apply();

        //Read suggestion array
        Gson gson = new Gson();
        String json = sharedPreferences.getString(SUGGESTIONS, null);
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        List<String> sugg = gson.fromJson(json, type);

        if(sugg == null) sugg = new ArrayList<>();

        if(!sugg.contains(query)) {
            if (sugg.size() >= 5) {
                if (sharedPreferences.getInt(MINCOUNT, Integer.MIN_VALUE) < preCount + 1) {
                    // Update suggestions array
                    for (String s : sugg) {
                        if (sharedPreferences.getInt(s, -1) == sharedPreferences.getInt(MINCOUNT, -2)) {
                            sugg.remove(sugg.indexOf(s));
                            sugg.add(query);

                            break;
                        }
                    }

                }
            } else sugg.add(query);

            String arrayToString = gson.toJson(sugg);
            editor.putString(SUGGESTIONS, arrayToString);
        }
        int min = Integer.MAX_VALUE;
        for (String option : sugg)
            min = Math.min(min, sharedPreferences.getInt(option, Integer.MAX_VALUE));

        editor.putInt(MINCOUNT, min);

        editor.apply();
    }

    private void init() {
        searchImageText = findViewById(R.id.search_edtText);
        searchButton = findViewById(R.id.searchIcon);
        sharedPreferences = getSharedPreferences(SHAREDPREF, MODE_PRIVATE);
    }
}
