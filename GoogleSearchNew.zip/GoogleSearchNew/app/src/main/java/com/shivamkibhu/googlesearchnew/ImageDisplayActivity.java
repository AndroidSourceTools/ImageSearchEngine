package com.shivamkibhu.googlesearchnew;

import androidx.appcompat.app.AppCompatActivity;
import androidx.paging.PagedList;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.widget.LinearLayout;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.paging.FirestorePagingOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class ImageDisplayActivity extends AppCompatActivity {
    private FirebaseFirestore db_Reference;
    private CollectionReference collectionReference;
    private ImageAdapter imageAdapter;
    private RecyclerView imagelist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_display);

        db_Reference = FirebaseFirestore.getInstance();
        collectionReference = db_Reference.collection("Images");
        setUpRecylerview();
    }

    @Override
    protected void onStart() {
        super.onStart();
        imageAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        imageAdapter.stopListening();
    }

    public void setUpRecylerview() {
        Query query = collectionReference;
        PagedList.Config config = new PagedList.Config.Builder().setInitialLoadSizeHint(10).setPageSize(5).build();
        FirestorePagingOptions<ImageModel> firestoreRecyclerOptions = new FirestorePagingOptions.Builder<ImageModel>()
                .setQuery(query, config, ImageModel.class).build();
        imageAdapter = new ImageAdapter(ImageDisplayActivity.this, firestoreRecyclerOptions);
        imagelist = findViewById(R.id.imageDisplay_recycler);
        StaggeredGridLayoutManager staggeredGrid = new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL);
        imagelist.setLayoutManager(staggeredGrid);
        imagelist.setAdapter(imageAdapter);
    }
}
